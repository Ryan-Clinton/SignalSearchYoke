> **Status (11 November 2026, added by the project):** an AI-written
> literature report, kept as research notes, **not a validated review**.
> Its citations were conversation-specific markers that did not survive
> export (67 of them); each is now shown as **†**. A statement
> marked † is unverified until its source is found again; the sources
> named in the text itself with a stable identifier are listed at the end.
> Nothing here is used by the project until its primary source has been
> read.

# SETI’s Forgotten Search Space: Historically Proposed Radio-Signal Hypotheses Worth Re-testing

## Scope, evidential standard and main conclusion

The historical record does **not** support a simple story in which early SETI researchers assumed that extraterrestrial signals must be continuous, perfectly monochromatic tones and ignored everything else. By the late 1970s and early 1980s, NASA-associated SETI work was explicitly considering drifting signals, pulses, modulation, polarisation, time averaging, adjacent-channel structure and multi-feature pattern recognition. Project OASIS, for example, was commissioned specifically because an eight-million-channel analyser generated too much information for straightforward inspection; its stated problem was how to process the resulting high-rate database, and a 1979 NASA conference paper described post-processing that included “the detection of drifting and modulated signals”. †

What *did* happen is subtler. Computational cost, limited storage and the need to impose extreme false-alarm control favoured a small number of tractable signal models. The most successful lineage became the narrowband, approximately continuous, approximately linear-Doppler search. Project META searched 8.4 million channels at 0.05-Hz resolution, while contemporary Breakthrough Listen searches commonly work at roughly 2.8–3-Hz spectral resolution and about 18-s time resolution and apply linear de-Doppler integration over a bounded drift-rate range. † The result is not that alternatives were unknown; it is that several alternatives were **proposed, sometimes prototyped, but never explored at anything like the scale now possible**.

The strongest surviving opportunities are therefore not “lost secrets”. They are combinations of established ideas that remain incompletely exercised against large public archives: scintillation-aware sub-threshold recurrence; low-duty-cycle narrowband pulse trains with simultaneous Doppler drift; and curved/non-linear Doppler tracks. Periodic spectral pulses and scintillation have recently received serious modern attention, so neither can be claimed as novel in itself. What remains potentially novel is the search regime, statistical combination and archival scale. †

The ranked backlog below deliberately rejects claims that an unexplained hit is evidence of intelligence. Radio-frequency interference, receiver artefacts, satellites, intermodulation products, noise excursions and ordinary propagation effects remain the default alternatives. The analysis also distinguishes **archived filterbank products**, which have already discarded phase and much fine time/frequency information, from **raw voltages**, from which alternative channelisations can in principle be constructed. Breakthrough Listen states that most observations are reduced to filterbanks occupying about 2% of the raw-data volume before raw voltages are deleted; public raw-voltage holdings therefore exist, but are highly incomplete relative to the filterbank archive. †

## What the historical projects actually assumed

Project Cyclops, completed in the early 1970s under Bernard Oliver and John Billingham, strongly influenced subsequent search design. NASA’s surviving catalogue describes it as a design study covering electromagnetic communication, signal processing and search strategy rather than as an observational search. † Its central narrowband reasoning was physically defensible: if transmitter power is constrained, longer integration concentrates energy into narrower bandwidth, while an engineered carrier can be far narrower than ordinary astronomical spectral lines. Cyclops nevertheless considered several modulation and pulse configurations in its system comparisons, so it is incorrect to portray the report as asserting that all artificial signals must be unmodulated continuous waves. †

Project OASIS is more damaging to the idea that early SETI was intellectually narrow. NASA’s 1981 report says an eight-million-channel spectrum analyser was already producing a database at “very high rates” and that OASIS was intended as the downstream detector. † A related NASA design paper explicitly listed power, phase coherence, polarisation, adjacent-channel aggregation, time averaging and detection of drifting and modulated signals. † That is remarkably close to what would now be called a multi-feature or anomaly-detection pipeline.

Horowitz’s Sentinel work also shows that line width was treated as a physical parameter rather than an arbitrary convention. The 1985 Sentinel paper states that its receiver had a “resolution bandwidth of 0.03Hz, matched to the Drake-Helou spreading of the interstellar medium.” † Sentinel therefore searched much finer spectral structure than the standard approximately 2.79-Hz Breakthrough Listen high-spectral-resolution products now publicly distributed. †

META, designed in 1983 and reported by Paul Horowitz and Carl Sagan in 1993, likewise did not assume a stationary received frequency. Their exact description was that Earth’s rotation “provides a characteristic changing Doppler signature for narrow-band signals of extraterrestrial origin.” † META corrected observations for several reference frames and achieved 0.05-Hz spectral resolution; after five years and roughly \(6\times10^{13}\) searched spectral channels, it had 37 above-threshold candidates that did not repeat. †

That failure to repeat became scientifically important. James Cordes, Joseph Lazio and Carl Sagan argued in 1997 that interstellar scintillation could make intrinsically steady narrowband transmitters intermittently visible. Their central, exactly verifiable recommendation was: **“We recommend that future surveys use thresholds far below the typical false-alarm threshold to lessen the effects of intermittency.”** † They did not claim the META events were extraterrestrial; indeed they explicitly compared receiver noise, scintillated steady sources and genuinely transient signals or hardware errors. † Subsequent re-analysis argued that a large population of steady scintillating beacons could be excluded for the META candidates at high confidence, so the historical claim was **tested and constrained**, not forgotten. †

A parallel line concerned pulses. D. K. Cullers’ 1986 paper, *Sensitive detection of narrowband pulses*, stated: **“Such a pulsed signal is, therefore, a good candidate for an extraterrestrial beacon.”** The proposed algorithm exploited the fact that concentrating the same energy into a low-duty-cycle pulse train can improve detectability; the paper reported a typical gain of about 7 dB for its assumed detector and said field-test software had been prepared for the NASA Multichannel Spectrum Analyzer. † This was therefore neither rejected nor merely speculative: it progressed to implementation work, but did not become the dominant survey mode.

## Ranked research backlog

| Rank | Hypothesis | Historical status | Modern overlap | Public-data testability | Compute on 16 CPU cores + GTX 1080 | Research value |
|---|---|---|---|---|---|---|
| **1** | Scintillation-aware, sub-threshold cross-epoch recurrence | Proposed 1997; partially tested | Strong modern work, but archival sub-threshold recurrence remains incompletely explored | Excellent with HSR filterbanks | Excellent | **High** |
| **2** | Doppler-drifting, low-duty-cycle narrowband pulse trains | Explicitly proposed and prototyped in 1986 | Periodic searches now exist, but parameter coverage is narrow | Excellent with mid-resolution; conditional with HSR | Good | **High** |
| **3** | Curved/non-linear Doppler tracks within and across scans | Physics recognised by META; later pipelines mostly linearised short observations | Surprisingly limited systematic archive-wide treatment | Excellent with HSR filterbanks | Good if hierarchical | **High** |
| **4** | Width-adaptive searches below the standard 2.8-Hz BL channel width | Explicitly motivated by Drake–Helou/Sentinel | Established concept, rarely possible from public reduced data | Poor in ordinary filterbanks; good only where raw voltages survive | Computationally feasible; I/O-heavy | **Medium** |
| **5** | OASIS-style multi-feature detector using modulation, temporal statistics and polarisation | Explicitly designed 1979–81 | ML/anomaly detection overlaps substantially | Mixed; phase/polarisation often lost in reduced products | Good on reduced data | **Medium** |
| **6** | Correlated multi-frequency/comb or structured-modulation events sharing a Doppler law | Modulated/drifting signals explicitly contemplated historically | Modern morphology and broadband work increasingly overlaps | Good for spectral-power structure; poor for coherent modulation without voltages | Good after candidate preselection | **Medium–low** |

**Scintillation-aware sub-threshold recurrence — Rank 1.** The primary historical source is Cordes, Lazio & Sagan, *Scintillation-Induced Intermittency in SETI* (submitted 2 July 1997; [original paper](https://arxiv.org/abs/astro-ph/9707039)). Their exact conclusion quoted above was not that scintillation proves artificiality but that detection thresholds and follow-up strategy can make a steady source look transient. They also stated that scintillation could “allow initial detections of narrowband signals from distant sources … while making redetections improbable”. † This hypothesis was subsequently attacked with additional META observations and constrained, so **the simple population model is not novel and should not be resurrected unchanged**. †

Modern work has revived the propagation aspect directly. Brzycki et al. in 2023 proposed identifying intensity scintillation of narrowband candidates as an RFI discriminator, and a 2024 Breakthrough Listen Galactic-centre experiment searched explicitly for scintillated technosignatures. It found no credible candidates and, importantly, found terrestrial RFI with scintillation-like intensity variability. † The genuine research gap is therefore narrower: search *below the normal single-scan detection threshold* for weak power at a common barycentric frequency/drift trajectory across independent epochs, then ask whether its amplitude statistics match the predicted scintillation distribution better than matched control frequencies and off-source observations.

A falsifiable experiment would take repeated GBT observations of the same targets, de-Doppler each scan over a modest physical drift range, preserve all peaks down to perhaps S/N 3–5 rather than S/N 10, and perform a hierarchical likelihood over epochs. Inject synthetic steady sources subjected to exponential or model-specific scintillation gain distributions; recover them blind; then apply the same analysis to offset sky positions and frequency-shuffled controls. A real astrophysical propagation signature should correlate with line-of-sight scattering predictions and remain sky-localised; terrestrial RFI should instead recur across unrelated pointings or exhibit transmitter-family structure. The 2024 scintillation search demonstrates that such discrimination is imperfect, which is precisely why negative controls are essential. †

Standard BL high-spectral-resolution filterbanks are adequate because the experiment needs intensity versus time and frequency, not electric-field phase. The usual product is approximately 2.79 Hz by 18.25 s, while BL additionally distributes intermediate and high-time-resolution products for some observations. † A 16-core machine can process target-sized subsets comfortably if the archive is frequency-windowed before analysis. The GTX 1080 has 8 GB of VRAM, so whole multi-gigabyte observations should be streamed in chunks rather than loaded at once. † The primary bottleneck is disk/network I/O, not the scintillation likelihood itself. The main false positives are weak persistent RFI, gain fluctuations, spectral leakage, standing-wave structure, noise selection bias and intermittently visible satellite transmissions. The novelty lies only in **deep sub-threshold cross-epoch statistical combination at archive scale**, not in scintillation theory.

**Doppler-drifting low-duty-cycle narrowband pulse trains — Rank 2.** Cullers’ 1986 paper ([NASA record](https://ntrs.nasa.gov/citations/20040090093); DOI 10.1016/0094-5765(86)90005-6) is an unusually clear historical precedent. It explicitly compared continuous narrowband accumulation with low-duty-cycle pulses of the same total energy and argued that the latter can be easier to detect under thresholded square-law processing. † The idea was therefore **implemented at prototype level rather than rejected**.

Modern SETI has now caught up partly. Suresh et al. introduced `blipss` and used a fast-folding algorithm on 4–8-GHz GBT data to search for channel-wide periodic signals with periods of 11–100 s and duty cycles of roughly 10–50%; they reported no detection. † The public implementation reports about 35 minutes to analyse one mid-resolution filterbank on a single CPU implementation, making a 16-core workstation entirely practical for modest campaigns. † What is not well covered is the **joint parameter space of lower duty cycle, narrow intrinsic bandwidth, and frequency drift during the observation**. A pulse train can be periodic in its own frame while each pulse shifts channel because of relative acceleration; applying a per-channel periodicity search before correcting drift loses coherence.

The decisive test is therefore a two-stage or joint matched filter: trial de-Doppler the spectrogram, then run an FFA or sparse-periodicity statistic, with periods from seconds to minutes and duty cycles below the `blipss` 10% floor. Synthetic signals should span missed pulses, variable pulse amplitude, linear drift, moderate quadratic curvature and scintillation. Run identical searches on off-source scans and frequency-shuffled spectra. The mid-resolution BL product, approximately 2.86 kHz by 1.07 s, is well suited to second-scale pulsed spectral features; HSR products provide narrower channels but only approximately 18-s samples, making them unsuitable for sub-18-s pulse morphology. † High-time-resolution products reach roughly 349.5 μs but at approximately 366 kHz spectral resolution and therefore cannot by themselves resolve a Hz–kHz narrowband carrier. † Raw voltages are required to obtain both very high time and high spectral resolution simultaneously.

False positives include rotating terrestrial radars, aircraft/satellite telemetry, periodic instrumental clocks, harmonics of mains or synthesiser clocks, pulsars if bandwidth/dispersion criteria are relaxed, and periodic masking caused by RFI excision. Injection/recovery plus off-source controls should be mandatory. The method itself is **established**, but a drift-corrected sparse-periodic search over a substantially wider duty-cycle range remains scientifically defensible.

**Non-linear Doppler trajectories — Rank 3.** The historical basis is strong. Horowitz & Sagan’s META paper did not merely anticipate a fixed offset: it explicitly identified the “characteristic changing Doppler signature” produced by Earth’s rotation. † Modern narrowband pipelines usually approximate such motion by a line over a short observation and use the Taylor-tree/de-Doppler algorithm to integrate power along constant drift-rate tracks. Contemporary reviews still describe the standard technique as an incoherent matched filter for **linearly** Doppler-accelerated signals. †

Linearisation is ordinarily reasonable over a five-minute scan, which is why this is not an obvious historical error. But it is not exact. BL’s `blc1` analysis found a narrowband interferer whose drift was approximately linear inside individual observing panels but changed smoothly over hours; detailed investigation eventually identified it as terrestrial intermodulation. † That case is useful as a control demonstration: **curvature is neither uniquely celestial nor uniquely artificial**.

The experiment is straightforward. Reanalyse HSR GBT observations using quadratic tracks

\[
f(t)=f_0+\dot f\,t+\tfrac12\ddot f\,t^2,
\]

first only around candidates recovered by an ordinary linear search. A full brute-force three-dimensional \(f_0,\dot f,\ddot f\) search would be wasteful on a GTX 1080; a hierarchical search is practical. Search linearly, retain weak candidates, then evaluate a grid of curvature terms or use a Hough/Radon-style transform locally. Across repeated scans, fit a physically smooth Doppler model instead of independent straight lines.

Public 2.79-Hz/18.25-s HSR data are sufficient for curvature that moves the signal by several Hz over minutes to hours, although they cannot recover phase-coherent sub-channel curvature. † The 8-GB GTX 1080 is adequate for chunked local searches; the limiting factor will again be archive volume rather than arithmetic throughput. † Modern surveys still frequently impose finite linear drift ranges, for example ±4 Hz s\(^{-1}\) in one BL galaxy search and up to 50 Hz s\(^{-1}\) in a recent COSMIC/VLA programme. †

The critical controls are synthetic chirps with known \(\ddot f\), fixed terrestrial tones, clock harmonics, satellites, spacecraft and on/off-source cadence. Candidate trajectories should also be checked against known observatory motion. Strong smooth curvature by itself is not persuasive: `blc1` is direct evidence that local electronics can imitate it. † Novelty here is **archive-scale curvature-aware recovery**, not the Doppler physics.

**Sub-Hz, width-adaptive spectral searches — Rank 4.** Horowitz and Forster’s Sentinel experiment directly searched at 0.03-Hz resolution because this was intended to match the expected interstellar broadening scale. Their exact historical wording is independently preserved by Cambridge: **“The dual-polarization 65,536-channel receiver has a resolution bandwidth of 0.03Hz, matched to the Drake-Helou spreading of the interstellar medium.”** † META subsequently operated at 0.05 Hz. † Thus sub-Hz radio SETI is not a modern invention.

The paradox is that the standard public BL HSR filterbank is coarser, about 2.79 Hz. † That does **not** make BL less sensitive overall—the modern system has enormously greater bandwidth and collecting/search capability—but it means those reduced products cannot reconstruct whether a detected three-hertz-wide feature was intrinsically 0.03 Hz, 0.3 Hz or 2 Hz. Once voltages have been averaged into a power spectrum, that information is gone.

A useful test would rechannelise surviving raw GBT voltages at multiple resolutions from approximately 0.03 Hz through tens of hertz and perform width-matched de-Doppler integration. Sensitivity should be validated with injected tones broadened by realistic scattering, oscillator instability and finite integration. Raw BL files are enormous: the public-data description reports approximately 16 GB for about 22.9 s per raw file, with a typical five-minute scan split into roughly 14 such files. † A single five-minute voltage scan can therefore exceed 200 GB. That makes a GTX 1080 computationally capable but operationally constrained by storage, PCIe/disk bandwidth and 8-GB VRAM. †

The decisive limitation is **data availability**, not mathematics. BL says most raw voltages are deleted after generation of reduced products, although raw public datasets do exist for selected targets and campaigns. † Consequently this is a valuable experiment only for a curated raw-voltage subset, not as an archive-wide filterbank reanalysis. False positives are synthesiser carriers, instrumental clocks, channelisation artefacts and stable terrestrial transmitters. This is established technique, not novelty.

**OASIS-style multi-feature anomaly detection — Rank 5.** The historical source is NASA’s 1981 Project OASIS report ([NASA catalogue](https://ntrs.nasa.gov/citations/19820016111)). Its motivating statement was that the MCSA produced “a very large data base at very high rates”. † A companion 1979 paper specified phase coherence, polarisation, neighbouring-channel aggregation, time averaging and drifting/modulated-signal detection. † In other words, a broad morphological detector was not absent from early SETI thinking; hardware limitations made exhaustive deployment difficult.

Modern machine learning has substantially occupied this territory. BL has already applied deep-learning methods to GBT observations to identify anomalous signals while filtering RFI; resulting signals of interest were not redetected. † A claim that “nobody has tried anomaly detection” would therefore be false.

A defensible experiment would be much more conservative than training an opaque “alien detector”. Compute interpretable OASIS-like features—spectral kurtosis, width, drift residual, temporal intermittency, neighbourhood entropy, polarisation where available and coincidence across scans—then compare unsupervised clusters against known RFI classes. COSMIC work is already applying excess kurtosis in RFI post-processing, reinforcing that these statistics are contemporary rather than forgotten. † Filterbank data are adequate for power-domain features but generally inadequate for phase coherence; full-Stokes/polarisation availability also varies by product. Raw voltages are required for the richest OASIS analogue.

A 16-core CPU plus GTX 1080 is sufficient for feature extraction and modest neural or clustering models once data are reduced. The dangerous false positive is exactly what modern anomaly detection tends to find: **rare human technology**. Negative controls must therefore include observations of RFI-rich blank fields, known satellites, calibrators and held-out observing sessions. The scientific novelty would lie in combining explicitly physical features with recurrence/sky localisation, not in machine learning itself.

**Cross-frequency structured signals and modulation families — Rank 6.** Early NASA post-processing designs already contemplated “drifting and modulated signals”, and Cyclops compared pulse and phase-shift-keyed communication modes. † Later SETI literature explicitly argued that information-bearing transmissions need not resemble an isolated carrier; spread-spectrum and more elaborate digital modulation make the search space much larger than the classic narrowband-tone model. †

The most tractable archival version is not to decode messages. It is to search for sets of separated spectral components whose drift trajectories are mutually correlated: combs, FSK-like hopping families or multiple lines sharing the same fractional Doppler evolution. A terrestrial clock tree or satellite transmitter can produce exactly the same morphology, so common drift is not evidence of extraterrestrial origin. The `blc1` investigation is particularly cautionary: dozens of related RFI features appeared at harmonically related frequencies and were traced to intermodulation around common clock oscillators. †

A falsifiable test would start from all narrowband hits, cluster them by common \(\dot f/f\), higher-order curvature and timing, and compare clustering strength between on-source and off-source scans. Randomly permuting frequencies within scans gives a null distribution. Filterbanks are sufficient for power-domain combs or FSK-like patterns; phase-coded or spread-spectrum detection generally requires raw voltage. A modern workstation can perform hit-level clustering cheaply because the dimensional reduction happens before the expensive correlation stage. The reason for ranking this below the first three is that terrestrial telecommunications make the false-positive space enormous, while the physical expectation for a particular alien modulation scheme is weak.

## Data sufficiency, throughput and required controls

Breakthrough Listen’s three common GBT reduced products occupy different parts of the time–frequency plane: roughly **2.79 Hz / 18.25 s** for high spectral resolution, **2.86 kHz / 1.07 s** for intermediate resolution, and **366 kHz / 349.5 μs** for high time resolution. † None simultaneously supplies sub-Hz spectral resolution and millisecond timing. Any proposal requiring both must return to raw voltages, where they still exist.

This distinction eliminates several otherwise attractive retrospective searches. A 0.03-Hz Sentinel-like analysis cannot be reconstructed from 2.79-Hz filterbanks. Coherent phase modulation cannot be inferred after power detection. Microsecond or millisecond pulses cannot be recovered from 18.25-s HSR integrations. Conversely, scintillation statistics on tens-of-seconds scales, linear and moderately curved Doppler tracks, long-period pulsed spectral signals and multi-epoch recurrence are all accessible in existing reduced products. †

Raw voltage is expensive. BL documentation describes approximately 16-GB chunks representing about 22.9 s of observation and approximately fourteen chunks for a typical five-minute scan. † Reprocessing merely 100 such five-minute observations can therefore involve order \(20\)–\(25\) TB of input. That is entirely manageable as a curated experiment but unpleasant on consumer storage. A GTX 1080 provides 8 GB of GDDR5X memory, so processing should be streamed by frequency subband and time chunk. †

For reduced filterbank analyses, the proposed workstation is much less problematic. `blipss` reports roughly 35 minutes on a single mid-resolution filterbank in its current CPU implementation, giving a useful empirical benchmark for pulse-search complexity; 16-way parallelism across files or subbands should make tens to hundreds of observations reasonable, though actual scaling will depend on I/O and memory. † GPU acceleration is attractive for de-Doppler and Hough/Radon transforms, but a GTX 1080 is old enough that algorithmic pruning matters more than brute-force floating-point performance.

The minimum negative-control design should be common to all six experiments. Every candidate statistic should be measured on off-source scans, frequency-shuffled data, time-scrambled data, known RFI-rich bands, synthetic injections and at least one astronomical control population such as pulsars or calibrators where appropriate. Any algorithm tuned on interesting-looking candidates must be re-run blind on held-out observations. This is especially important because BL’s `blc1` analysis demonstrated that local intermodulation can simultaneously imitate narrow bandwidth, Doppler drift, temporal persistence and apparent on/off-source behaviour. †

The archive itself should be treated as a survey with a selection function, not as an unbiased random sample. Different targets have different receivers, dates, observing cadences, RFI environments and data products. BL’s public archive contains more than a petabyte of data and exposes raw, filterbank and related products, but raw-voltage completeness is much poorer than reduced-data completeness. † A null result therefore constrains only the searched signal morphology within the subset where adequate data exist.

## Hypotheses that should be rejected or deprioritised

Several apparently “forgotten” ideas do not survive adversarial review. The claim that scintillation explains the historical META events as a population of steady extraterrestrial beacons is already substantially constrained by later META analysis and should not be presented as an open explanation awaiting its first test. † What remains worthwhile is the more general statistical question of how scintillation changes detection and re-detection probability.

Likewise, periodic radio technosignature searches are no longer neglected. `blipss` has explicitly searched periodic spectral signals with a fast-folding algorithm in GBT data. † The defensible gap is lower duty cycle, larger period range, and joint pulse-plus-Doppler modelling.

Ultra-narrowband detection is also thoroughly established historically. Sentinel operated at 0.03 Hz and META at 0.05 Hz. † Repeating such a search at modern scale would be useful but not conceptually novel; moreover, ordinary public BL filterbanks cannot recover the required information.

Claims that smooth Doppler drift is a reliable “artificiality test” should also be rejected. Natural astronomical masers and other spectral lines are broader than classic Hz-scale SETI targets, but terrestrial and spaceborne technology routinely produces narrow drifting carriers. The `blc1` case is an empirical warning that a technically generated local signal can reproduce an apparently compelling drift morphology. †

Pure unconstrained anomaly hunting is low priority. Modern BL machine-learning work has already demonstrated that anomalous-looking features can be discovered efficiently, but absence of a physically motivated statistic leaves an enormous RFI interpretation burden. † A more productive revival of OASIS is interpretable multi-feature modelling tied to sky localisation, propagation or a shared dynamical trajectory.

Finally, broad-band technosignatures are no longer an untouched frontier. By 2026, published work was explicitly developing broadband radio-technosignature frameworks combining brightness temperature, spectral structure, scintillation, polarisation and astrometric association. † A generic “search broadband signals instead of narrowband ones” proposal therefore has little novelty; a credible project must specify a morphology and discrimination strategy.

## The three strongest hypotheses

**First: scintillation-aware sub-threshold recurrence.** The historical anchor is Cordes, Lazio & Sagan, 1997, *Scintillation-Induced Intermittency in SETI* ([original paper](https://arxiv.org/abs/astro-ph/9707039)). Their exact recommendation to search below the normal false-alarm threshold is unusually prescient because modern archives permit precisely the kind of cross-epoch statistical aggregation that was expensive then. † The decisive experiment is to de-Doppler repeated GBT target scans, retain statistically weak features, and ask whether repeated power at a common celestial frequency follows a scintillation likelihood while remaining absent from matched off-source and frequency-shuffled controls. Standard HSR BL filterbanks are sufficient. Modern scintillation searches mean the physics is established rather than novel, but the **sub-threshold multi-epoch archive search** remains a credible research contribution. It may fail because weak RFI and receiver gain fluctuations can reproduce intermittency, because scintillation timescales may not match the observing cadence, because surviving BL target repetitions may be too sparse, or simply because no relevant transmitter exists. †

**Second: Doppler-corrected sparse periodic narrowband pulses.** The historical anchor is Cullers, 1986, *Sensitive Detection of Narrowband Pulses* ([NASA bibliographic record](https://ntrs.nasa.gov/citations/20040090093)). Its key claim was that low-duty-cycle pulse trains can outperform continuous accumulation for fixed energy, and the work progressed as far as field-test software. † The decisive modern experiment is to inject and recover pulse trains with duty cycles below 10%, unknown periods, missing pulses and non-zero Doppler drift, then run the validated detector over repeated GBT observations with strict on/off-source controls. `blipss` makes periodicity itself established; the potentially useful contribution is the joint sparse-periodic/de-Doppler parameter search. † It may fail because rotating radars and satellite transmitters inhabit exactly this morphology, because public data do not simultaneously provide Hz spectral resolution and sub-second timing, or because low-duty-cycle beacons are no more physically probable than continuous ones.

**Third: curvature-aware Doppler recovery.** The historical anchor is Horowitz & Sagan’s 1993 META analysis ([NASA record](https://ntrs.nasa.gov/citations/19930072472)), which explicitly recognised the changing Doppler signature caused by terrestrial motion. † The decisive experiment is a hierarchical quadratic-drift search on BL HSR data: ordinary linear de-Doppler first, then a curvature grid around weak candidates, followed by cross-scan fitting to a smooth physically allowed trajectory and aggressive RFI controls. The existing 2.79-Hz/18.25-s data are adequate for curvature that accumulates several channels over a scan or observing sequence. † This is computationally realistic on a 16-core CPU and GTX 1080 if implemented hierarchically rather than as a brute-force three-dimensional search. It may fail because five-minute scans are short enough that curvature rarely matters, because terrestrial oscillators and satellites generate equally convincing nonlinear drifts, because candidate gains over an optimal linear fit may be negligible, or because the most interesting curvature lies below the resolution already lost during filterbank formation. The technique would therefore be an **extension of established de-Doppler searches, not a new technosignature class**. †

## Sources, checked by the project (11 November 2026)

Each looked up at its stable record; "checked" means the record exists
with these details and, where said, supports the claim the report makes
of it. The papers themselves have not all been read in full.

- Cordes, J. M., Lazio, T. J. W. & Sagan, C. (1997), *Scintillation-Induced
  Intermittency in SETI*, ApJ 487, 782; arXiv:astro-ph/9707039. The source
  of the report's scintillation argument.
- Lazio, T. J. W., Tarter, J. & Backus, P. R. (2002), *Megachannel
  Extraterrestrial Assay Candidates: No Transmissions from Intrinsically
  Steady Sources*, AJ; arXiv:astro-ph/0203516. Re-observed nine of META's
  eleven candidates and excluded scintillating steady sources at 97.8%
  confidence or more: the "subsequent re-analysis" the report cites
  without a name.
- Cullers, D. K. (1986), *Sensitive detection of narrowband pulses*, Acta
  Astronautica 13(1); DOI 10.1016/0094-5765(86)90005-6; NASA NTRS
  20040090093. The NTRS record gives the "about 7 dB" gain and the
  rotating-beacon remark the report quotes.
- Horowitz, P. & Sagan, C. (1993), *Five years of Project META: an all-sky
  narrow-band radio search for extraterrestrial signals*, ApJ 415, 218;
  DOI 10.1086/173157; NASA NTRS 19930072472.
- Lord, S., Dixon, R. & Healy, T. (1981), *Project OASIS: The Design of a
  Signal Detector for the Search for Extraterrestrial Intelligence*,
  NASA-TM-84738; NASA NTRS 19820016111. Holds the sentence "The MCSA puts
  out a very large data base at very high rates", as the report quotes.
- Brzycki, B. et al. (2023), *On Detecting Interstellar Scintillation in
  Narrowband Radio SETI*, ApJ 952, 46; arXiv:2307.08793 (the `blscint`
  library).
- Suresh, A. et al. (2023), *A 4-8 GHz Galactic Center Search for Periodic
  Technosignatures*, AJ 165, 255; DOI 10.3847/1538-3881/acccf0;
  arXiv:2305.18527 (BLIPSS: periods 11 to 100 s, duty cycles 10 to 50%,
  kHz-wide signals, no detection).
- Sheikh, S. Z. et al. (2019), *Choosing a Maximum Drift Rate in a SETI
  Search: Astrophysical Considerations*, ApJ 884, 14; arXiv:1910.01148;
  and Li, M. G. et al. (2023), *Developing a Drift Rate Distribution for
  Technosignature Searches of Exoplanets*, AJ 166, 182; arXiv:2311.01427
  (99% of confirmed exoplanets within ±53 nHz; ±0.44 nHz for a bias-reduced
  population). Not cited by the report; added for its curvature section.

Named in the text but not yet found again: Project Cyclops (Oliver &
Billingham 1971, NASA CR-114445 by other accounts, unchecked); Horowitz &
Forster's Sentinel paper (1985) and its "0.03 Hz" quotation; the 2024
Breakthrough Listen Galactic-centre scintillation search; the `blc1`
analyses (Sheikh et al. 2021; Smith et al. 2021); Breakthrough Listen's
data-product descriptions (the product figures the report gives match
this project's own files: 2.79 Hz by 18.25 s); the COSMIC/VLA programme;
the 2026 broadband framework.
